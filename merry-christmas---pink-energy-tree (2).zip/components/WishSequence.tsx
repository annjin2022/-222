import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

// --- FIREWORK SHADERS ---
const fwVertexShader = `
  uniform float uTime;
  uniform float uSize;
  
  attribute vec3 aDirection;
  attribute vec3 aColor;
  attribute float aSpeed;
  attribute float aDelay;
  
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    vColor = aColor;
    
    // Physics simulation in vertex shader
    float t = max(0.0, uTime - aDelay);
    
    vec3 pos = position;
    
    // Explosion movement: direction * speed * time
    // Apply "Drag" (slow down over time): pow(t, 0.9)
    vec3 movement = aDirection * (aSpeed * 15.0) * pow(t, 0.92);
    
    // Gravity
    movement.y -= 4.0 * t * t; 
    
    vec3 finalPos = pos + movement;
    
    vec4 mvPosition = modelViewMatrix * vec4(finalPos, 1.0);
    
    // Size attenuation
    gl_PointSize = uSize * (1.0 / length(mvPosition.xyz));
    
    // Alpha fade out
    float life = 1.0 - (t / 3.0); // 3 seconds duration
    vAlpha = smoothstep(0.0, 0.2, life) * smoothstep(1.0, 0.8, life);
    
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fwFragmentShader = `
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    if (vAlpha <= 0.0) discard;
    
    vec2 coord = gl_PointCoord - vec2(0.5);
    float dist = length(coord);
    
    if (dist > 0.5) discard;
    
    // Sparkle core
    float glow = 1.0 - (dist * 2.0);
    glow = pow(glow, 3.0);
    
    gl_FragColor = vec4(vColor, vAlpha * glow);
  }
`;

// --- EXPLOSION COMPONENT ---
const Explosion: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const startTime = useRef<number | null>(null);

  const particleCount = 5000; // Increased count for fuller effect
  
  const { positions, directions, colors, speeds, delays } = useMemo(() => {
    const pos = new Float32Array(particleCount * 3);
    const dir = new Float32Array(particleCount * 3);
    const col = new Float32Array(particleCount * 3);
    const spd = new Float32Array(particleCount);
    const dly = new Float32Array(particleCount);
    
    const colorPalette = [
        new THREE.Color('#ff0000'), // Red
        new THREE.Color('#ffcc00'), // Gold
        new THREE.Color('#00ffcc'), // Cyan
        new THREE.Color('#ff00ff'), // Magenta
        new THREE.Color('#ffffff'), // White
        new THREE.Color('#ff69b4'), // Hot Pink
    ];

    for (let i = 0; i < particleCount; i++) {
        // Start at top heart
        pos[i*3] = 0;
        pos[i*3+1] = 12;
        pos[i*3+2] = 0;
        
        // Random Direction Sphere
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos((Math.random() * 2) - 1);
        
        dir[i*3] = Math.sin(phi) * Math.cos(theta);
        dir[i*3+1] = Math.sin(phi) * Math.sin(theta);
        dir[i*3+2] = Math.cos(phi);
        
        // Random Color from palette
        const c = colorPalette[Math.floor(Math.random() * colorPalette.length)];
        col[i*3] = c.r;
        col[i*3+1] = c.g;
        col[i*3+2] = c.b;
        
        spd[i] = Math.random() * 0.8 + 0.5; // Slightly faster base speed
        dly[i] = Math.random() * 0.1; // Tighter burst
    }
    
    return { positions: pos, directions: dir, colors: col, speeds: spd, delays: dly };
  }, []);

  useFrame((state) => {
    if (!materialRef.current) return;
    
    if (startTime.current === null) {
        startTime.current = state.clock.elapsedTime;
    }
    
    const elapsed = state.clock.elapsedTime - startTime.current;
    materialRef.current.uniforms.uTime.value = elapsed;
    
    if (elapsed > 4.0) {
        onComplete();
    }
  });

  return (
    <points>
        <bufferGeometry>
            <bufferAttribute attach="attributes-position" count={particleCount} array={positions} itemSize={3} />
            <bufferAttribute attach="attributes-aDirection" count={particleCount} array={directions} itemSize={3} />
            <bufferAttribute attach="attributes-aColor" count={particleCount} array={colors} itemSize={3} />
            <bufferAttribute attach="attributes-aSpeed" count={particleCount} array={speeds} itemSize={1} />
            <bufferAttribute attach="attributes-aDelay" count={particleCount} array={delays} itemSize={1} />
        </bufferGeometry>
        <shaderMaterial 
            ref={materialRef}
            vertexShader={fwVertexShader}
            fragmentShader={fwFragmentShader}
            uniforms={{
                uTime: { value: 0 },
                uSize: { value: 200.0 }
            }}
            transparent
            depthWrite={false}
            blending={THREE.AdditiveBlending}
        />
    </points>
  );
};

// --- MAIN WRAPPER ---
interface WishSequenceProps {
    status: 'IDLE' | 'EXPLODING';
    onComplete: () => void;
}

export const WishSequence: React.FC<WishSequenceProps> = ({ status, onComplete }) => {
    if (status === 'IDLE') return null;

    return (
        <>
            {status === 'EXPLODING' && <Explosion onComplete={onComplete} />}
        </>
    );
};