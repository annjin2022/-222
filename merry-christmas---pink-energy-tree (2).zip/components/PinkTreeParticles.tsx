import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG } from '../constants';

// --- SHADERS ---

const vertexShader = `
  uniform float uTime;
  uniform float uHeight;
  
  attribute float aScale;
  attribute vec3 aColor;
  attribute float aSpeed;
  attribute float aPhase;
  
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    vColor = aColor;
    
    vec3 pos = position;
    
    // Breathing animation: expanding/contracting slightly based on height and time
    float breath = sin(uTime * 2.0 + aPhase) * 0.05;
    pos.x += pos.x * breath;
    pos.z += pos.z * breath;
    
    // Gentle floating upward simulation (visual trick, actually manipulating y slightly)
    float floatOffset = sin(uTime * aSpeed + pos.y) * 0.1;
    pos.y += floatOffset;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    
    // Size attenuation
    gl_PointSize = aScale * (300.0 / -mvPosition.z);
    
    // Twinkling effect in alpha
    vAlpha = 0.6 + 0.4 * sin(uTime * 3.0 + aPhase * 10.0);

    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    // Soft particle circle
    vec2 coord = gl_PointCoord - vec2(0.5);
    float dist = length(coord);
    
    if (dist > 0.5) discard;
    
    // Glow gradient: center is bright, edge fades out
    float glow = 1.0 - (dist * 2.0);
    glow = pow(glow, 1.5); // Soften the curve
    
    gl_FragColor = vec4(vColor, glow * vAlpha);
  }
`;

export const PinkTreeParticles: React.FC = () => {
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  
  // Generate Particle Data
  const { positions, colors, scales, speeds, phases } = useMemo(() => {
    const count = CONFIG.PARTICLE_COUNT;
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const scales = new Float32Array(count);
    const speeds = new Float32Array(count);
    const phases = new Float32Array(count);

    const tempColor = new THREE.Color();

    for (let i = 0; i < count; i++) {
      // Cone Logic
      // Normalized height (0 to 1)
      const h = Math.random(); 
      // Current radius at this height (linear cone)
      // Tree tapers to top (h=1 -> r=0, h=0 -> r=Max)
      const coneRadiusAtY = CONFIG.TREE_RADIUS * (1.0 - h);
      
      // Random angle
      const theta = Math.random() * Math.PI * 2;
      // Random radius within the cone volume (square root for uniform distribution)
      const r = Math.sqrt(Math.random()) * coneRadiusAtY;

      const x = r * Math.cos(theta);
      const z = r * Math.sin(theta);
      const y = h * CONFIG.TREE_HEIGHT;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      // --- COLOR LOGIC REFINED ---
      
      // 1. Normalized Radial Distance (0 at center, 1 at edge)
      // Add small epsilon to avoid divide by zero at very top
      const normalizedR = r / (coneRadiusAtY + 0.001);
      
      // 2. Height Factor (1.0 at bottom, 0.0 at top)
      const heightFactor = 1.0 - Math.max(0, Math.min(1, h));
      
      // 3. Determine if Outer Shell
      // Threshold: r > 0.75 is outer shell
      const isOuterShell = normalizedR > 0.75;
      
      if (isOuterShell) {
        // Probabilities scale with heightFactor (more special colors at bottom)
        const pLightPink = 0.25 * heightFactor;
        const pGold = 0.15 * heightFactor;
        
        const rand = Math.random();
        
        if (rand < pLightPink) {
            tempColor.copy(CONFIG.COLOR_LIGHT_PINK);
        } else if (rand < pLightPink + pGold) {
            tempColor.copy(CONFIG.COLOR_GOLD);
        } else {
            // Remaining outer particles use main warm pinks
            tempColor.copy(Math.random() > 0.5 ? CONFIG.COLOR_WARM_PINK : CONFIG.COLOR_SOFT_PINK);
        }
      } else {
        // Inner particles: Only Warm Pink and Soft Pink
        tempColor.copy(Math.random() > 0.5 ? CONFIG.COLOR_WARM_PINK : CONFIG.COLOR_SOFT_PINK);
      }

      // Add slight jitter/noise to prevent banding
      tempColor.offsetHSL(0, (Math.random() - 0.5) * 0.05, (Math.random() - 0.5) * 0.05);

      colors[i * 3] = tempColor.r;
      colors[i * 3 + 1] = tempColor.g;
      colors[i * 3 + 2] = tempColor.b;

      // Scale: Top particles smaller, bottom larger mixed
      scales[i] = Math.random() * 0.4 + 0.2;

      speeds[i] = Math.random() + 0.5;
      phases[i] = Math.random() * Math.PI * 2;
    }

    return { positions, colors, scales, speeds, phases };
  }, []);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
    }
  });

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={CONFIG.PARTICLE_COUNT}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aColor"
          count={CONFIG.PARTICLE_COUNT}
          array={colors}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aScale"
          count={CONFIG.PARTICLE_COUNT}
          array={scales}
          itemSize={1}
        />
        <bufferAttribute
          attach="attributes-aSpeed"
          count={CONFIG.PARTICLE_COUNT}
          array={speeds}
          itemSize={1}
        />
         <bufferAttribute
          attach="attributes-aPhase"
          count={CONFIG.PARTICLE_COUNT}
          array={phases}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={{
          uTime: { value: 0 },
          uHeight: { value: CONFIG.TREE_HEIGHT },
        }}
        transparent={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};