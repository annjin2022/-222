import React from 'react';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import { CONFIG } from '../constants';

export const SceneEffects: React.FC = () => {
  return (
    <EffectComposer disableNormalPass>
      <Bloom 
        luminanceThreshold={CONFIG.BLOOM_THRESHOLD}
        mipmapBlur 
        intensity={CONFIG.BLOOM_INTENSITY}
        radius={CONFIG.BLOOM_RADIUS} 
      />
      <Noise opacity={0.05} />
      <Vignette eskil={false} offset={0.1} darkness={0.5} />
    </EffectComposer>
  );
};