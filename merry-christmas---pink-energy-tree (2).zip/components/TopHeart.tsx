import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG } from '../constants';

interface TopHeartProps {
  position: [number, number, number];
}

const vertexShader = `
  uniform float uTime;
  attribute float aScale;
  attribute vec3 aColor;
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    vColor = aColor;
    
    // Pulse animation handled via uniform scale in useFrame, 
    // but we add internal turbulence here
    vec3 pos = position;
    
    // Subtle internal movement
    pos.x += sin(uTime * 3.0 + position.y * 5.0) * 0.02;
    pos.y += cos(uTime * 2.0 + position.x * 5.0) * 0.02;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_PointSize = aScale * (100.0 / -mvPosition.z); // Slightly smaller base size for density
    
    // Constant high alpha for density
    vAlpha = 0.8 + 0.2 * sin(uTime * 5.0 + position.x);

    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  varying vec3 vColor;
  varying float vAlpha;

  void main() {
    vec2 coord = gl_PointCoord - vec2(0.5);
    float dist = length(coord);
    if (dist > 0.5) discard;
    
    // Sharp core, soft glow
    float glow = 1.0 - (dist * 2.0);
    glow = pow(glow, 0.5); // Harder glow for denser look
    
    gl_FragColor = vec4(vColor, vAlpha * glow);
  }
`;

export const TopHeart: React.FC<TopHeartProps> = ({ position }) => {
  const groupRef = useRef<THREE.Group>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  // Generate Heart Volume Particles
  const { positions, colors, scales } = useMemo(() => {
    const count = 2500; // High density
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const scales = new Float32Array(count);
    const tempColor = new THREE.Color();

    for (let i = 0; i < count; i++) {
      // 2D Heart Shape Formula (16sin^3(t), 13cos(t)-5cos(2t)...)
      // We fill it by randomizing t (angle) and r (scale/radius)
      
      const t = Math.random() * Math.PI * 2;
      // Use sqrt(random) for uniform distribution, but we want dense core + clear edge
      // Let's mix distribution: some uniform, some concentrated on edge
      let u = Math.random();
      let scaleC = Math.sqrt(u); // Uniform spread
      
      // 20% chance to be exactly on the edge (0.95-1.0) for outline definition
      if (Math.random() < 0.2) {
         scaleC = 0.9 + Math.random() * 0.1;
      }

      // Basic Heart Curve (scaled down)
      // x = 16 sin^3(t)
      // y = 13 cos(t) - 5 cos(2t) - 2 cos(3t) - cos(4t)
      const hx = 16 * Math.pow(Math.sin(t), 3);
      const hy = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);

      // Apply scaleC and global size scale (divide by ~16 to normalize to unitish)
      const sizeFactor = 0.08; 
      const x = hx * scaleC * sizeFactor;
      const y = hy * scaleC * sizeFactor;
      
      // Z-depth: Thicker in middle, thinner at edges to make a 3D volume
      const zThickness = 0.4 * (1 - scaleC * 0.5); 
      const z = (Math.random() - 0.5) * zThickness;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      // Color Logic
      // 70% Main Deep Pink
      // 20% Soft Pink (Glow)
      // 10% Gold (Sparkles)
      const randC = Math.random();
      if (randC < 0.7) {
        tempColor.copy(CONFIG.COLOR_HEART_MAIN);
      } else if (randC < 0.9) {
        tempColor.copy(CONFIG.COLOR_SOFT_PINK);
      } else {
        tempColor.copy(CONFIG.COLOR_GOLD);
      }
      
      // Boost brightness for edge particles
      if (scaleC > 0.9) {
         tempColor.multiplyScalar(1.2);
      }

      colors[i * 3] = tempColor.r;
      colors[i * 3 + 1] = tempColor.g;
      colors[i * 3 + 2] = tempColor.b;

      // Scale variation
      scales[i] = Math.random() * 0.8 + 0.4;
    }

    return { positions, colors, scales };
  }, []);

  useFrame((state) => {
    const time = state.clock.elapsedTime;
    
    if (groupRef.current) {
        // Bobbing
        groupRef.current.position.y = position[1] + Math.sin(time * 2) * 0.1;
        // Slow rotation
        groupRef.current.rotation.y = time * 0.5;
        
        // Heartbeat Pulse Animation
        // Pulse pattern: Beat... Beat... wait. 
        // sin wave is okay, but pow(sin) makes it sharper
        const pulse = 1.0 + 0.05 * Math.pow(Math.sin(time * 3), 2);
        groupRef.current.scale.set(pulse, pulse, pulse);
    }
    
    if (materialRef.current) {
        materialRef.current.uniforms.uTime.value = time;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Particle Volume */}
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={positions.length / 3} array={positions} itemSize={3} />
          <bufferAttribute attach="attributes-aColor" count={colors.length / 3} array={colors} itemSize={3} />
          <bufferAttribute attach="attributes-aScale" count={scales.length} array={scales} itemSize={1} />
        </bufferGeometry>
        <shaderMaterial
          ref={materialRef}
          vertexShader={vertexShader}
          fragmentShader={fragmentShader}
          uniforms={{ uTime: { value: 0 } }}
          transparent={true}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </points>
      
      {/* Halo / Glow Sprite behind */}
      <mesh position={[0, 0, 0]}>
         <planeGeometry args={[4, 4]} />
         <meshBasicMaterial 
            color={CONFIG.COLOR_HEART_MAIN} 
            transparent 
            opacity={0.15} 
            blending={THREE.AdditiveBlending}
            depthWrite={false}
         >
             <canvasTexture attach="map" image={createGlowTexture()} />
         </meshBasicMaterial>
      </mesh>
      
      {/* Internal Point Light */}
      <pointLight color="#ff0040" intensity={1.5} distance={6} decay={2} />
    </group>
  );
};

// Helper to create a soft glow texture for the halo
function createGlowTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
    grad.addColorStop(0.4, 'rgba(255, 255, 255, 0.2)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
  }
  return canvas;
}
