import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

const vertexShader = `
  uniform float uTime;
  uniform float uActive;
  
  attribute float aScale;
  attribute float aSpeed;
  attribute vec3 aOffset; // Initial random position offset
  
  varying float vAlpha;
  varying vec3 vColor;
  
  void main() {
    // Current loop time for this particle
    float t = uTime * aSpeed;
    
    // Position Logic
    // Start at aOffset and float upwards
    vec3 pos = position;
    
    // Spiral upwards
    float angle = t * 0.5 + aOffset.x * 10.0;
    float radius = 5.0 + sin(t * 0.8) * 2.0; // Oscillate radius
    
    // Reset height modulo to loop particles
    float height = mod(t * 4.0 + aOffset.y * 20.0, 30.0) - 10.0;
    
    pos.x = cos(angle) * radius;
    pos.z = sin(angle) * radius;
    pos.y = height;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_PointSize = aScale * (300.0 / -mvPosition.z);
    
    // Fade in/out based on uActive and height (fade at top and bottom)
    float heightAlpha = 1.0 - smoothstep(15.0, 20.0, height);
    float startAlpha = smoothstep(-10.0, -5.0, height);
    
    vAlpha = uActive * heightAlpha * startAlpha;

    // Generate Rainbow Color based on random offset and slight time cycling
    // Cosine palette technique
    float hue = aOffset.x * 10.0 + uTime * 0.2;
    vec3 rainbow = 0.5 + 0.5 * cos(vec3(hue, hue + 2.09, hue + 4.18)); 
    vColor = rainbow;
    
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  varying float vAlpha;
  varying vec3 vColor;

  void main() {
    if (vAlpha < 0.01) discard;

    // Heart Shape SDF logic
    vec2 p = gl_PointCoord - vec2(0.5);
    
    // Transform coordinate space to make math easier
    // Shift Y down slightly so tip is centered
    p.y -= 0.1;
    
    // Mathematical trick: transform heart shape to circle
    // Standard Heart formula approximation: p.y - |p.x| * scale
    // If we subtract abs(x) from y, we flatten the top V and point the bottom
    float sy = p.y + abs(p.x) * 0.5; // Factor controls shape
    
    // Check distance - now roughly a circle check on distorted space
    float r = length(vec2(p.x, sy));
    
    if (r > 0.35) discard;
    
    // Soft glow edge
    float glow = 1.0 - smoothstep(0.2, 0.35, r);
    
    gl_FragColor = vec4(vColor, vAlpha * glow);
  }
`;

interface FloatingHeartsProps {
  active: boolean;
}

export const FloatingHearts: React.FC<FloatingHeartsProps> = ({ active }) => {
  const mesh = useRef<THREE.Points>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const currentActive = useRef(0);

  const particleCount = 200;

  const { positions, scales, speeds, offsets } = useMemo(() => {
    const positions = new Float32Array(particleCount * 3);
    const scales = new Float32Array(particleCount);
    const speeds = new Float32Array(particleCount);
    const offsets = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = 0; 
      positions[i * 3 + 1] = 0;
      positions[i * 3 + 2] = 0;

      scales[i] = Math.random() * 0.5 + 0.3;
      speeds[i] = Math.random() * 0.5 + 0.5;
      
      offsets[i * 3] = Math.random(); // Random starting angle offset
      offsets[i * 3 + 1] = Math.random(); // Random height offset
      offsets[i * 3 + 2] = Math.random(); 
    }

    return { positions, scales, speeds, offsets };
  }, []);

  useFrame((state, delta) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      
      // Smooth fade in/out
      const target = active ? 1.0 : 0.0;
      currentActive.current = THREE.MathUtils.lerp(currentActive.current, target, delta * 2.0);
      materialRef.current.uniforms.uActive.value = currentActive.current;
    }
  });

  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={particleCount} array={positions} itemSize={3} />
        <bufferAttribute attach="attributes-aScale" count={particleCount} array={scales} itemSize={1} />
        <bufferAttribute attach="attributes-aSpeed" count={particleCount} array={speeds} itemSize={1} />
        <bufferAttribute attach="attributes-aOffset" count={particleCount} array={offsets} itemSize={3} />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={{
          uTime: { value: 0 },
          uActive: { value: 0 }
        }}
        transparent={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};