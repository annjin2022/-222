import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import { PinkTreeParticles } from './PinkTreeParticles';
import { SnowParticles } from './SnowParticles';
import { BaseRings } from './BaseRings';
import { TopHeart } from './TopHeart';
import { FloatingHearts } from './FloatingHearts';
import { SceneEffects } from './SceneEffects';
import * as THREE from 'three';

// Wrapper component to handle the group animation logic inside Canvas
const InteractiveTreeGroup: React.FC<{
  scaleTarget: number;
  rotationTarget: { x: number; y: number } | null;
  swipeDirection: 'LEFT' | 'RIGHT' | null;
  children: React.ReactNode;
}> = ({ scaleTarget, rotationTarget, swipeDirection, children }) => {
  const groupRef = useRef<THREE.Group>(null);
  const currentScale = useRef(1);
  const spinTarget = useRef(0); // Target total rotation offset

  useEffect(() => {
    if (swipeDirection === 'RIGHT') {
        spinTarget.current += Math.PI * 2;
    } else if (swipeDirection === 'LEFT') {
        spinTarget.current -= Math.PI * 2;
    }
  }, [swipeDirection]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // 1. Smooth Scale Interpolation
    const lerpFactor = 5 * delta;
    currentScale.current = THREE.MathUtils.lerp(currentScale.current, scaleTarget, lerpFactor);
    groupRef.current.scale.set(currentScale.current, currentScale.current, currentScale.current);

    // 2. Rotation Logic
    // We combine the base rotation (from spin) and the tilt (from hand position)
    
    // Smoothly interpolate current Y rotation towards spinTarget
    const isSpinning = Math.abs(groupRef.current.rotation.y - spinTarget.current) > 0.05;
    
    if (isSpinning) {
       const step = (spinTarget.current - groupRef.current.rotation.y) * 4.0 * delta;
       groupRef.current.rotation.y += step;
       groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, 0, lerpFactor);
       
    } else if (rotationTarget) {
      const handOffsetX = (rotationTarget.x - 0.5) * 2.0; 
      const targetRotY = spinTarget.current + handOffsetX;
      const targetRotX = (rotationTarget.y - 0.5) * 0.5;

      groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, targetRotY, lerpFactor);
      groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, targetRotX, lerpFactor);
    } else {
       groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, spinTarget.current, lerpFactor * 0.5);
       groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, 0, lerpFactor * 0.5);
    }
  });

  return (
    <group ref={groupRef} position={[0, -5, 0]}>
      {children}
    </group>
  );
};

interface SceneProps {
  gestureScale: number;
  gestureRotation: { x: number; y: number } | null;
  swipeDirection: 'LEFT' | 'RIGHT' | null;
  isHeartGesture: boolean;
}

export const PinkParticleTreeScene: React.FC<SceneProps> = ({ 
  gestureScale, 
  gestureRotation, 
  swipeDirection, 
  isHeartGesture,
}) => {
  return (
    <Canvas
      dpr={[1, 2]} 
      gl={{ 
        antialias: false,
        toneMapping: THREE.ReinhardToneMapping,
        toneMappingExposure: 1.5,
        alpha: false 
      }}
    >
      <color attach="background" args={['#050205']} />
      
      <PerspectiveCamera makeDefault position={[0, 4, 18]} fov={45} />
      
      <OrbitControls 
        enablePan={false} 
        enableZoom={true} 
        minDistance={10} 
        maxDistance={30}
        autoRotate={!gestureRotation && !swipeDirection && !isHeartGesture} 
        autoRotateSpeed={0.5}
        maxPolarAngle={Math.PI / 2 - 0.1}
      />

      {/* Interactive Group wraps the Tree components */}
      <InteractiveTreeGroup 
        scaleTarget={gestureScale} 
        rotationTarget={gestureRotation}
        swipeDirection={swipeDirection}
      >
        <PinkTreeParticles />
        <TopHeart position={[0, 12, 0]} />
        <BaseRings />
      </InteractiveTreeGroup>

      {/* Global Environment */}
      <SnowParticles />
      <FloatingHearts active={isHeartGesture} />
      
      <SceneEffects />
    </Canvas>
  );
};