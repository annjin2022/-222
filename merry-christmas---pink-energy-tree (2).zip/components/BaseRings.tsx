import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG } from '../constants';

const Ring: React.FC<{ radius: number; speed: number; count: number; yOffset: number }> = ({ radius, speed, count, yOffset }) => {
  const ref = useRef<THREE.Points>(null);

  const points = React.useMemo(() => {
    const pos = new Float32Array(count * 3);
    const angleStep = (Math.PI * 2) / count;
    for (let i = 0; i < count; i++) {
      const angle = angleStep * i;
      pos[i * 3] = Math.cos(angle) * radius;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 0.2; // Minor vertical jitter
      pos[i * 3 + 2] = Math.sin(angle) * radius;
    }
    return pos;
  }, [radius, count]);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * speed;
      // Gentle bobbing
      ref.current.position.y = yOffset + Math.sin(state.clock.elapsedTime + radius) * 0.1;
    }
  });

  return (
    <points ref={ref} position={[0, yOffset, 0]}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" count={count} array={points} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial
        color={CONFIG.COLOR_EDGE}
        size={0.2}
        transparent
        opacity={0.8}
        blending={THREE.AdditiveBlending}
        depthWrite={false}
      />
    </points>
  );
};

export const BaseRings: React.FC = () => {
  return (
    <group>
      <Ring radius={CONFIG.TREE_RADIUS * 1.1} speed={0.2} count={200} yOffset={0.2} />
      <Ring radius={CONFIG.TREE_RADIUS * 1.3} speed={-0.15} count={300} yOffset={0} />
      <Ring radius={CONFIG.TREE_RADIUS * 1.5} speed={0.1} count={400} yOffset={-0.2} />
    </group>
  );
};