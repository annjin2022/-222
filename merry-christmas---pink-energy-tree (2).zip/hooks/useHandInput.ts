import { useState, useEffect, useRef, useCallback } from 'react';
import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

export interface HandInputState {
  isReady: boolean;
  cameraEnabled: boolean;
  toggleCamera: () => void;
  gesture: 'OPEN' | 'CLOSED' | 'NONE';
  swipeDirection: 'LEFT' | 'RIGHT' | null;
  isHeartGesture: boolean;
  position: { x: number; y: number } | null;
  error: string | null;
}

export function useHandInput(): HandInputState {
  const [isReady, setIsReady] = useState(false);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [gesture, setGesture] = useState<'OPEN' | 'CLOSED' | 'NONE'>('NONE');
  const [swipeDirection, setSwipeDirection] = useState<'LEFT' | 'RIGHT' | null>(null);
  const [isHeartGesture, setIsHeartGesture] = useState(false);
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const landmarkerRef = useRef<HandLandmarker | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const requestRef = useRef<number>(null);
  const isLooping = useRef(false);
  
  // Swipe detection refs
  const positionHistory = useRef<{x: number, time: number}[]>([]);
  const lastSwipeTime = useRef(0);

  useEffect(() => {
    const init = async () => {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm"
        );
        landmarkerRef.current = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`,
            delegate: "GPU"
          },
          runningMode: "VIDEO",
          numHands: 2 // Enabled 2 hands for Heart Gesture
        });
        setIsReady(true);
      } catch (e) {
        setError("Failed to load hand tracking model");
        console.error(e);
      }
    };
    init();

    return () => {
      if (videoRef.current && videoRef.current.parentNode) {
        videoRef.current.parentNode.removeChild(videoRef.current);
      }
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, []);

  const predict = useCallback(() => {
    if (!isLooping.current || !landmarkerRef.current || !videoRef.current) return;

    if (videoRef.current.videoWidth === 0) {
        requestRef.current = requestAnimationFrame(predict);
        return;
    }

    try {
        const nowInMs = Date.now();
        const result = landmarkerRef.current.detectForVideo(videoRef.current, nowInMs);

        let detectedGesture: 'OPEN' | 'CLOSED' | 'NONE' = 'NONE';
        let detectedPos = null;

        if (result.landmarks && result.landmarks.length > 0) {
          
          // --- HEART GESTURE DETECTION (Requires 2 Hands) ---
          if (result.landmarks.length === 2) {
             const h1 = result.landmarks[0];
             const h2 = result.landmarks[1];

             // Index 4: Thumb Tip, Index 8: Index Finger Tip
             const t1 = h1[4];
             const i1 = h1[8];
             const t2 = h2[4];
             const i2 = h2[8];

             // Calculate distance between thumbs and index fingers
             const thumbDist = Math.hypot(t1.x - t2.x, t1.y - t2.y);
             const indexDist = Math.hypot(i1.x - i2.x, i1.y - i2.y);

             // Thresholds: if tips are close enough, it's a heart
             // Note: Depending on hand orientation, left/right might be swapped, but distance check is invariant
             if (thumbDist < 0.2 && indexDist < 0.2) {
                 setIsHeartGesture(true);
                 // Reset other gestures to avoid conflict
                 setGesture('NONE');
                 setSwipeDirection(null);
                 setPosition(null); 
                 
                 // If heart is detected, skip single hand logic
                 if (isLooping.current) requestRef.current = requestAnimationFrame(predict);
                 return;
             } else {
                 setIsHeartGesture(false);
             }
          } else {
             setIsHeartGesture(false);
          }

          // --- SINGLE HAND LOGIC (Swipe / Open / Close) ---
          // Use the first detected hand for basic control
          const landmarks = result.landmarks[0];
          
          const wrist = landmarks[0];
          const mcp = landmarks[9]; 
          const palmSize = Math.sqrt(Math.pow(wrist.x - mcp.x, 2) + Math.pow(wrist.y - mcp.y, 2));
          
          const tips = [4, 8, 12, 16, 20].map(i => landmarks[i]);
          let avgTipDist = 0;
          tips.forEach(t => {
            avgTipDist += Math.sqrt(Math.pow(t.x - wrist.x, 2) + Math.pow(t.y - wrist.y, 2));
          });
          avgTipDist /= 5;

          const ratio = avgTipDist / palmSize;

          if (ratio > 1.6) detectedGesture = 'OPEN';
          else if (ratio < 1.3) detectedGesture = 'CLOSED';
          
          setGesture(detectedGesture);
          
          // Position (Mirrored X)
          const visualX = 1 - wrist.x;
          detectedPos = { x: visualX, y: wrist.y };
          setPosition(detectedPos);

          // --- SWIPE DETECTION (Index Finger Tip Tracking) ---
          const indexTip = landmarks[8];
          const currentVisualX = 1 - indexTip.x;
          
          positionHistory.current.push({ x: currentVisualX, time: nowInMs });
          if (positionHistory.current.length > 10) positionHistory.current.shift();

          if (nowInMs - lastSwipeTime.current > 1000 && positionHistory.current.length >= 5) {
              const start = positionHistory.current[0];
              const end = positionHistory.current[positionHistory.current.length - 1];
              
              const dx = end.x - start.x;
              const dt = end.time - start.time;

              if (dt > 50) {
                  const velocity = dx / (dt / 1000);
                  if (Math.abs(velocity) > 1.5) {
                      const direction = velocity > 0 ? 'RIGHT' : 'LEFT';
                      setSwipeDirection(direction);
                      lastSwipeTime.current = nowInMs;
                      setTimeout(() => setSwipeDirection(null), 500);
                  }
              }
          }

        } else {
          setIsHeartGesture(false);
          // Optional: decay gesture state?
        }
    } catch (err) {
        console.warn("Prediction error:", err);
    }

    if (isLooping.current) {
      requestRef.current = requestAnimationFrame(predict);
    }
  }, []);

  const toggleCamera = useCallback(async () => {
    if (cameraEnabled) {
      isLooping.current = false;
      setCameraEnabled(false);
      
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(t => t.stop());
        videoRef.current.srcObject = null;
      }
      
      setGesture('NONE');
      setSwipeDirection(null);
      setIsHeartGesture(false);
      setPosition(null);
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                facingMode: 'user',
                width: { ideal: 640 },
                height: { ideal: 480 }
            } 
        });
        
        if (!videoRef.current) {
          videoRef.current = document.createElement('video');
          videoRef.current.style.position = 'absolute';
          videoRef.current.style.top = '0';
          videoRef.current.style.left = '0';
          videoRef.current.style.opacity = '0'; 
          videoRef.current.style.pointerEvents = 'none';
          videoRef.current.style.zIndex = '-1';
          videoRef.current.setAttribute('playsinline', 'true');
          videoRef.current.setAttribute('muted', 'true');
          document.body.appendChild(videoRef.current);
        }
        
        videoRef.current.srcObject = stream;
        
        videoRef.current.onloadeddata = async () => {
            await videoRef.current?.play();
            setCameraEnabled(true);
            isLooping.current = true;
            requestRef.current = requestAnimationFrame(predict);
        };
        
      } catch (e) {
        setError("Camera access denied. Please check permissions.");
        console.error("Camera Error:", e);
      }
    }
  }, [cameraEnabled, predict]);

  return { isReady, cameraEnabled, toggleCamera, gesture, swipeDirection, isHeartGesture, position, error };
}