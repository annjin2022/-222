import React, { Suspense, useState, useEffect, useRef } from 'react';
import { PinkParticleTreeScene } from './components/PinkParticleTreeScene';
import { useHandInput } from './hooks/useHandInput';

const App: React.FC = () => {
  const { isReady, cameraEnabled, toggleCamera, gesture, swipeDirection, isHeartGesture, position, error } = useHandInput();
  
  // Audio State
  const [musicEnabled, setMusicEnabled] = useState(false);
  const [audioState, setAudioState] = useState<'LOADING' | 'READY' | 'ERROR'>('LOADING');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize Audio with Fallback Logic
  useEffect(() => {
    const PLAYLIST = [
      'https://assets.mixkit.co/music/preview/mixkit-we-wish-you-a-merry-christmas-396.mp3',
      'https://upload.wikimedia.org/wikipedia/commons/transcoded/9/9b/We_Wish_You_a_Merry_Christmas.ogg/We_Wish_You_a_Merry_Christmas.ogg.mp3',
      'https://ia800501.us.archive.org/12/items/WeWishYouAMerryChristmas_576/We%20Wish%20You%20a%20Merry%20Christmas.mp3'
    ];
    
    const audio = new Audio();
    audio.loop = true;
    audio.volume = 0.4;
    audio.crossOrigin = "anonymous";
    audio.preload = "auto";
    
    let currentSrcIndex = 0;

    const loadSource = () => {
      if (currentSrcIndex >= PLAYLIST.length) {
        console.warn("All audio sources failed to load.");
        setAudioState('ERROR');
        return;
      }
      
      setAudioState('LOADING');
      audio.src = PLAYLIST[currentSrcIndex];
      audio.load();
    };

    const handleCanPlay = () => {
      setAudioState('READY');
    };

    const handleError = (e: Event) => {
      console.warn(`Audio source ${currentSrcIndex} failed. Trying next...`);
      currentSrcIndex++;
      loadSource();
    };

    audio.addEventListener('canplaythrough', handleCanPlay);
    audio.addEventListener('error', handleError);
    
    loadSource();
    
    audioRef.current = audio;

    return () => {
      audio.pause();
      audio.removeEventListener('canplaythrough', handleCanPlay);
      audio.removeEventListener('error', handleError);
      audio.src = '';
      audioRef.current = null;
    };
  }, []);

  const toggleMusic = () => {
    if (!audioRef.current || audioState !== 'READY') return;

    if (musicEnabled) {
      audioRef.current.pause();
      setMusicEnabled(false);
    } else {
      const playPromise = audioRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
             setMusicEnabled(true);
          })
          .catch((err) => {
            console.error("Audio play prevented:", err);
            setMusicEnabled(false);
          });
      }
    }
  };

  const targetScale = gesture === 'OPEN' ? 3 : 1;

  const getMusicButtonLabel = () => {
    if (audioState === 'LOADING') return 'LOADING MUSIC...';
    if (audioState === 'ERROR') return 'MUSIC UNAVAILABLE';
    return musicEnabled ? 'DISABLE MUSIC' : 'ENABLE MUSIC';
  };

  // UI Helper for active interaction
  const getActiveStatus = () => {
    if (isHeartGesture) return "HEART DETECTED ❤️";
    if (swipeDirection) return `SWIPE ${swipeDirection}`;
    return gesture;
  };

  return (
    <div className="relative w-full h-full bg-[#050505] text-white overflow-hidden">
      {/* Cinematic Overlay UI */}
      <div className="absolute top-0 left-0 w-full h-full z-10 pointer-events-none flex flex-col justify-between p-8 md:p-12">
        <header className="flex justify-between items-start opacity-80 pointer-events-auto">
          <div>
            <h1 className="text-sm font-bold tracking-[0.3em] text-pink-300 uppercase">Interactive Experience</h1>
            <p className="text-xs text-pink-100/50 mt-1 font-mono">XMAS-2024-BUILD-V1.0</p>
            {cameraEnabled && (
               <div className="mt-2 text-xs font-mono text-pink-400 space-y-1">
                  <p>STATUS: <span className="text-white font-bold">{getActiveStatus()}</span></p>
                  {!isHeartGesture && <p>POS: {position ? `${position.x.toFixed(2)}, ${position.y.toFixed(2)}` : 'N/A'}</p>}
               </div>
            )}
          </div>
          
          <div className="flex flex-col items-end gap-2">
             <div className="flex gap-2 mb-2">
                <div className={`w-2 h-2 rounded-full ${isReady ? 'bg-green-400' : 'bg-yellow-400'} animate-pulse`}></div>
                <span className="text-xs font-mono text-green-400">SYSTEM {isReady ? 'ONLINE' : 'LOADING AI...'}</span>
             </div>
             
             {/* Music Toggle */}
             <button 
                onClick={toggleMusic}
                disabled={audioState !== 'READY'}
                className={`
                    pointer-events-auto px-4 py-2 text-xs font-bold tracking-widest uppercase border transition-all duration-300 w-40
                    ${audioState === 'ERROR' ? 'opacity-50 cursor-not-allowed border-red-500/50 text-red-500/50' : ''}
                    ${audioState === 'LOADING' ? 'opacity-70 cursor-wait border-white/20 text-white/50' : ''}
                    ${audioState === 'READY' && musicEnabled 
                        ? 'bg-amber-500/20 border-amber-500 text-amber-200 shadow-[0_0_10px_rgba(251,191,36,0.5)]' 
                        : audioState === 'READY' ? 'bg-transparent border-white/20 text-white/50 hover:border-white/50 hover:text-white' : ''}
                `}
             >
                {getMusicButtonLabel()}
             </button>

             {/* Camera Toggle */}
             <button 
                onClick={toggleCamera}
                disabled={!isReady}
                className={`
                    pointer-events-auto px-4 py-2 text-xs font-bold tracking-widest uppercase border transition-all duration-300 w-40
                    ${cameraEnabled 
                        ? 'bg-pink-500/20 border-pink-500 text-pink-200 shadow-[0_0_10px_rgba(236,72,153,0.5)]' 
                        : 'bg-transparent border-white/20 text-white/50 hover:border-white/50 hover:text-white'}
                    ${!isReady && 'opacity-50 cursor-not-allowed'}
                `}
             >
                {cameraEnabled ? 'DISABLE CAMERA' : 'ENABLE CAMERA'}
             </button>
             {error && <p className="text-xs text-red-400 font-mono">{error}</p>}
          </div>
        </header>

        {/* Gestures Feedback Overlay - Only show for Heart, hide for swipe */}
        {isHeartGesture && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none text-center">
             <div className="text-4xl font-bold tracking-widest animate-pulse p-6 rounded-xl backdrop-blur-md shadow-2xl bg-black/60 drop-shadow-[0_0_30px_rgba(255,255,255,0.4)]">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-yellow-400 via-green-400 via-blue-500 to-purple-500">
                    ✨ WISHING YOU ALL THE BEST! ✨
                </span>
             </div>
          </div>
        )}

        <footer className="w-full flex justify-center pb-8">
            <div className="text-center animate-pulse">
                <h2 className="text-4xl md:text-6xl font-serif text-transparent bg-clip-text bg-gradient-to-r from-sky-200 via-cyan-300 to-blue-200 tracking-widest drop-shadow-[0_0_15px_rgba(56,189,248,0.5)]">
                    MERRY CHRISTMAS
                </h2>
                <p className="text-sky-200/60 text-sm mt-2 tracking-[0.5em] font-light">
                   {cameraEnabled ? "MAKE A HEART ❤️ OR SWIPE TO CONTROL" : "WISHING YOU A MAGICAL HOLIDAY"}
                </p>
            </div>
        </footer>
      </div>

      {/* 3D Scene */}
      <div className="absolute inset-0 z-0">
        <Suspense fallback={
            <div className="w-full h-full flex items-center justify-center text-pink-400 font-mono text-sm tracking-widest">
                INITIALIZING PARTICLES...
            </div>
        }>
            <PinkParticleTreeScene 
                gestureScale={targetScale} 
                gestureRotation={position} 
                swipeDirection={swipeDirection}
                isHeartGesture={isHeartGesture}
            />
        </Suspense>
      </div>
      
      {/* Vignette Overlay */}
      <div className="absolute inset-0 z-20 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)]"></div>
    </div>
  );
};

export default App;