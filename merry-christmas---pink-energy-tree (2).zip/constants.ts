import * as THREE from 'three';

export const CONFIG = {
  // Tree Dimensions
  TREE_HEIGHT: 12,
  TREE_RADIUS: 4.5,
  PARTICLE_COUNT: 15000,
  
  // Colors - Refined Palette
  COLOR_LIGHT_PINK: new THREE.Color('#FFEBF0'), // Outer shell highlight
  COLOR_GOLD: new THREE.Color('#FBC968'),       // Champagne gold sparkles
  COLOR_WARM_PINK: new THREE.Color('#FF6B90'),  // Main tree warm pink
  COLOR_SOFT_PINK: new THREE.Color('#FF9FB5'),  // Secondary soft pink
  
  COLOR_HEART_MAIN: new THREE.Color('#DF0041'), // Deep warm pink for heart
  
  COLOR_EDGE: new THREE.Color('#ffd700'),       // Keep for rings
  
  // Animation
  ROTATION_SPEED: 0.1,
  FLOAT_AMPLITUDE: 0.2,
  FLOAT_SPEED: 1.5,
  
  // Effects
  BLOOM_INTENSITY: 1.5,
  BLOOM_THRESHOLD: 0.6,
  BLOOM_RADIUS: 0.8,
};